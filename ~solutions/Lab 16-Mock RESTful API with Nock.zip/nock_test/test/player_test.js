var expect = require('chai').expect;
var supertest = require('supertest');
var nock = require('nock');
var url = 'http://localhost:5000';
var api = supertest(url);

describe('Player', function() {

    beforeEach(function() {
        nock(url)
        .get('/players/1')
        .reply(200, {id: 1, name: 'Crosby'});
       nock(url)
        .get('/players/3')
        .reply(404, 'Not found');
    });

    it('Status code - test', function(done) {
        api.get('/players/1')
           .expect(200)
           .end(function(err, res) {
                done();
           });
        }); 

        it('Values - test', function(done) {
            api.get('/players/1')
               .expect(200)
               .end(function(err, res) {
                   expect(res.body.id).to.equal(1);
                   expect(res.body.name).to.equal('Crosby');
                   done();
               })
          });	

          it('Invalid player - test', function(done) {
            api.get('/players/3')
               .set('Accept', 'application/json')
               .expect(404)	
               .end(function(err, res) {
                  expect(res.text).to.equal('Not found');
                  done();
                });
            });

});

