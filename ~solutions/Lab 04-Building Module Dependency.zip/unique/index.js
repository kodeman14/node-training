var uuid = require("uuid");

var value = uuid.v4(); //Generate v4 uuid
console.log("UUID is: %s", value);