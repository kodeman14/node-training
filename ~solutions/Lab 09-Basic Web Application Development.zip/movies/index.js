var http = require('http');

var movies = [
    {
      name:"Vampire in Brooklyn",
      releaseYear: 1995,
      tagLine:"A comic tale of horror and seduction."
    },
    {
      name:"Alien vs. Predator",
      releaseYear:2004,
      tagLine:"Whoever wins, we lose."
    },
    {
      name:"Chicken Run",
      releaseYear:2000,
      tagLine:"Escape or die frying."
    }
  ];

var server = http.createServer(function(req, res) {
    res.setHeader("Content-type", "application/json");

    if (req.method === "GET") {
      res.write(JSON.stringify(movies));
      res.end();
    } else if (req.method === "POST") {
        var body = "";

        req.on("data", function(chunk) {
            body += chunk;
        });

        req.on("end", function() {
            var newMovie = JSON.parse(body);
            movies.push(newMovie);
            res.end();
        });
    }
});

server.listen(3000);