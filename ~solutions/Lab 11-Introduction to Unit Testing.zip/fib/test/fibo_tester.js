var fib = require("../../fib");
var chai = require("chai");

describe('Main test suite', function() {
    it('Edge case 1', function () {
        chai.assert.equal(fib.calculate(1), 1, "Should be 1");
    });
    it('Edge case 2', function () {
      chai.assert.equal(fib.calculate(2), 1, "Should be 1");
    });
    it('Regular case', function () {
      chai.assert.equal(fib.calculate(10), 55, "Should be 55");
    });
});