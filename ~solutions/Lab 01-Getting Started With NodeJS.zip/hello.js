var planet = "World"; //Default planet

if (process.argv.length > 2) {
  planet = process.argv[2]; //3rd parameter
}

console.log("Hello %s!", planet);