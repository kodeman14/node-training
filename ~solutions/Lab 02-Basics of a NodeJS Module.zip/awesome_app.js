var auth = require("./auth");

function test_login(userId, password) {
    if (auth.login(userId, password)) {
      console.log("%s logged in fine!", userId);
    } else {
      console.log("%s can't login.", userId);
    }
  }
  
  test_login("daffy", "d12");
  test_login("bob", "pass123");