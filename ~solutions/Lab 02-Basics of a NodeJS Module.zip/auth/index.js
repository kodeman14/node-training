module.exports.login = function(userId, password) {
    //Awesome auth logic
    if (userId === "bob" && password === "pass123") {
      return true;
    }
    
    return false;
  }