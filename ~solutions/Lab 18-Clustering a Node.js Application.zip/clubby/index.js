var cluster = require('cluster');
var numCPUs = require('os').cpus().length * 2;

if (cluster.isMaster) {
  for (var i = 0; i < numCPUs; i++) {
    console.log("Forking a new child...");
    cluster.fork();
  }
  
  cluster.on('exit', function(worker, code, signal) {
    console.log('Worker process %d has died.', worker.process.pid);
    cluster.fork();
  });
} else {
  //Start the web application
  var clubby = require('./clubby');
}console.log("Request served by process: %d", process.pid);