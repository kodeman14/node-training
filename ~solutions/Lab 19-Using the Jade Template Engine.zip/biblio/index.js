var express = require('express');
var bodyParser = require('body-parser');
var dao = require("./data_access");

var app = express();

app.set('views', __dirname + '/views');
app.set('view engine', 'jade');

app.use(bodyParser.json()); //Parse JSON body

app.get("/books/:isbn", (req, res) => {
  dao.findBook(req.params.isbn, (err, book) => {
    if (book !== undefined) {
      //We have a book
      res.send(book);
    } else {
      res.statusCode = 404;
      res.end();
    }
  });
});

  app.put("/books/:isbn", (req, res) => {
    if (req.params.isbn === undefined || req.body === undefined) {
      res.statusCode = 500;
      res.end();
  
      return;
    }
  
    dao.updateBook(req.params.isbn, req.body, (err) => {
      if (err !== null) {
        res.statusCode = 500;
      }
      res.end();
    });
    
  });

  app.get("/books", (req, res) => {
    dao.findAllBooks(req.params.isbn, (err, books) => {
      if (books !== undefined) {
        res.render("book_list", {
          book_collection: books
        });
      } else {
        res.statusCode = 500;
        res.end();
      }
    });
  });

  app.listen(3000);