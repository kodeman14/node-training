var rl = require("./readline");

rl.readLine(process.argv[2], function(line) {
  console.log("Read line: %s", line);
});