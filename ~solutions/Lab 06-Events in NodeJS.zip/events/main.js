var bank_account = require('./bank_account.js');
var events = require('events');
var util = require('util');

var account = new bank_account.BankAccount();
util.inherits(account, events.EventEmitter);

account.on("low_balance", function(currentBalance, newBalance) {
    console.log('MANAGER - Low balance!!!. Current balance is: ' + currentBalance + ", Balance will become: " + newBalance);
  });

account.on("low_balance", function(currentBalance, newBalance) {
    console.log('CUSTOMER - Low balance!!!. Current balance is: ' + currentBalance + ", Balance will become: " + newBalance);
  });


account.deposit(100);
account.withdraw(110);
