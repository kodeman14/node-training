var expect = require('chai').expect;
var supertest = require('supertest');
var api = supertest('http://localhost:3000');

describe('Book', function() {


it('Status code - test', function(done) {
    api.get('/books/1')
      .set('Accept', 'application/json')
      .expect(200, done);
  });

  it('Values - test', function(done) {
    api.get('/books/1')
       .set('Accept', 'application/json')
       .expect(200)
       .end(function(err, res) {
           expect(res.body).to.have.property('title');
           expect(res.body.title).to.equal('Lord of the rings');
           done();
       })
    });

	it('Update - test', function(done) {
        api.put('/books/2')
           .set('Accept', 'application/json')
           .send({
            title: 'new book',
            author: 'me'
           })
           .expect(200)
           .end(function(err, res) {
               
           });
               
        api.get('/books/2')
                 .set('Accept', 'application/json')
           .expect(200)	
           .end(function(err, res) {
            expect(res.body.title).to.equal('new book');
            expect(res.body.author).to.equal('me');
            done();
            });
        });
        
        it('Invalid book - test', function(done) {
            api.get('/books/3')
               .set('Accept', 'application/json')
               .expect(404)	
               .end(function(err, res) {
                    if(err) return done(err);
                        done();
                });
        });

    });